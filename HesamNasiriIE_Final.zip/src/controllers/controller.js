
class Controller{
    constructor(){
         
    }

}

module.exports = Controller;